import { useState } from "react";
import Contact from "./contact";

const ContactList = ({ initialContacts }) => {
  const [contacts, setContacts] = useState(initialContacts);
  const [form, setForm] = useState({
    nombre: "",
    apellido: "",
    telefono: ""
  });

  const addContact = () => {
    if (!form.nombre || !form.apellido || !form.telefono) return;

    setContacts([
      ...contacts,
      {
        id: Date.now(),
        ...form,
        favorito: false
      }
    ]);

    setForm({ nombre: "", apellido: "", telefono: "" });
  };

  const deleteContact = (id) => {
    setContacts(contacts.filter(c => c.id !== id));
  };

  const toggleFavorite = (id) => {
    setContacts(
      contacts.map(c =>
        c.id === id ? { ...c, favorito: !c.favorito } : c
      )
    );
  };

  const orderedContacts = [
    ...contacts.filter(c => c.favorito),
    ...contacts.filter(c => !c.favorito)
  ];

  return (
    <>
      <h2> Lista de Contactos</h2>

      <div className="form">
        <input
          placeholder="Nombre"
          value={form.nombre}
          onChange={e => setForm({ ...form, nombre: e.target.value })}
        />
        <input
          placeholder="Apellido"
          value={form.apellido}
          onChange={e => setForm({ ...form, apellido: e.target.value })}
        />
        <input
          placeholder="Teléfono"
          value={form.telefono}
          onChange={e => setForm({ ...form, telefono: e.target.value })}
        />
        <button onClick={addContact}> Agregar</button>
      </div>

      {orderedContacts.map(contact => (
        <Contact
          key={contact.id}
          contact={contact}
          onDelete={deleteContact}
          onToggleFavorite={toggleFavorite}
        />
      ))}
    </>
  );
};

export default ContactList;