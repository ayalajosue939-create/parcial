const Contact = ({ contact, onDelete, onToggleFavorite }) => {
  return (
    <div className={`contact ${contact.favorito ? "favorito" : ""}`}>
      <div>
        <strong>{contact.nombre} {contact.apellido}</strong>
        <p> {contact.telefono}</p>
      </div>

      <div className="actions">
        <button onClick={() => onToggleFavorite(contact.id)}>
          {contact.favorito ? "+ Quitar favorito" : "- Agregar favorito"}
        </button>
        <button onClick={() => onDelete(contact.id)}> Eliminar</button>
      </div>
    </div>
  );
};

export default Contact;