import ContactList from "./componentes/contactList";
import contactsData from "./data/contacts.json";
import "./index.css";

function App() {
  return <ContactList initialContacts={contactsData} />;
}

export default App;